#!/usr/bin/env python3
"""
autoswagger_minimal.py
Discover Swagger/OpenAPI spec, hit every endpoint, print results.
No external dependencies — stdlib only (Python 3.11+).
"""

import argparse
import json
import os
import re
import ssl
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from itertools import product as itertools_product
from urllib.parse import urljoin, urlencode, urlparse
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# ── SSL context (skip cert verification, mirrors requests verify=False) ────────
_SSL = ssl.create_default_context()
_SSL.check_hostname = False
_SSL.verify_mode = ssl.CERT_NONE

TIMEOUT = 10
TOTAL_REQUESTS = 0
_lock = threading.Lock()

# ── Swagger/OpenAPI discovery paths ────────────────────────────────────────────
SWAGGER_UI_PATHS = sorted({
    "/", "/apidocs/", "/swagger/ui/index", "/swagger/index.html", "/swagger-ui.html",
    "/swagger/swagger-ui.html", "/api/swagger-ui.html", "/api_docs", "/api/index.html",
    "/api/doc", "/api/docs/", "/api/swagger/index.html", "/api/swagger/swagger-ui.html",
    "/api/swagger-ui/api-docs", "/api/api-docs", "/api/apidocs", "/api/swagger",
    "/api/swagger/static/index.html", "/api/swagger-resources",
    "/docu", "/docs", "/swagger", "/api-doc", "/doc/",
    "/webjars/swagger-ui/index.html", "/Swagger", "/Swagger/", "/Swagger/index.html",
    "/admin/swagger-ui/index.html", "/api-doc/", "/api-docs/",
    "/api/", "/api/api-docs", "/api/spec/", "/spec/",
})

DIRECT_SPEC_PATHS = sorted({
    "/swagger.json", "/swagger.yaml", "/swagger.yml",
    "/api/swagger.json", "/api/swagger.yaml", "/api/swagger.yml",
    "/v1/swagger.json", "/v1/swagger.yaml",
    "/v2/swagger.json", "/v2/swagger.yaml",
    "/v3/swagger.json", "/v3/swagger.yaml",
    "/openapi.json", "/openapi.yaml", "/openapi.yml",
    "/api/openapi.json", "/api/openapi.yaml", "/api/openapi.yml",
    "/docs/swagger.json", "/docs/openapi.json",
    "/api-docs/swagger.json", "/api-docs/openapi.json",
    "/swagger/v1/swagger.json", "/swagger/swagger.json",
    "/rest/swagger.json", "/spec/swagger.json", "/spec/openapi.json",
    "/api/v3/openapi.json", "/api/v3/openapi.yaml",
})

# ── Test values for path/query param fuzzing ───────────────────────────────────
TEST_VALUES = {
    "integer": [1, 2, 100],
    "string":  ["1", "test", "550e8400-e29b-41d4-a716-446655440000"],
    "boolean": ["true", "false"],
    "number":  [1, 0],
    "default": ["1", "test"],
}

# ── Minimal YAML parser (covers OpenAPI spec subset) ──────────────────────────

def _yaml_coerce(v):
    v = v.strip()
    if v in ('null', 'Null', 'NULL', '~', ''):
        return None
    if v in ('true', 'True', 'TRUE'):
        return True
    if v in ('false', 'False', 'FALSE'):
        return False
    try:
        return int(v)
    except ValueError:
        pass
    try:
        return float(v)
    except ValueError:
        pass
    return v

def _yaml_unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] in ('"', "'") and s[-1] == s[0]:
        return s[1:-1]
    return s

def _split_kv(s):
    if s.startswith('"'):
        end = s.index('"', 1)
        key = s[1:end]
        rest = s[end+1:].strip()
        return key, (rest[1:] if rest.startswith(':') else '')
    if s.startswith("'"):
        end = s.index("'", 1)
        key = s[1:end]
        rest = s[end+1:].strip()
        return key, (rest[1:] if rest.startswith(':') else '')
    idx = s.find(':')
    return (s[:idx], s[idx+1:]) if idx != -1 else (s, '')

def _collect_block_scalar(lines, start, min_indent, style):
    val_lines = []
    i = start
    block_indent = None
    while i < len(lines):
        raw = lines[i]
        stripped = raw.lstrip()
        if not stripped:
            val_lines.append('')
            i += 1
            continue
        bi = len(raw) - len(stripped)
        if block_indent is None:
            if bi < min_indent:
                break
            block_indent = bi
        if bi < block_indent:
            break
        val_lines.append(raw[block_indent:])
        i += 1
    sep = '\n' if style == '|' else ' '
    return sep.join(val_lines).strip(), i

def _parse_block(lines, start, min_indent):
    result = None
    i = start
    n = len(lines)

    while i < n:
        raw = lines[i]
        stripped = raw.lstrip()
        if not stripped or stripped.startswith('#'):
            i += 1
            continue
        indent = len(raw) - len(stripped)
        if indent < min_indent:
            break

        if stripped.startswith('- ') or stripped == '-':
            if result is None:
                result = []
            item_str = stripped[2:].strip() if stripped.startswith('- ') else ''
            if item_str:
                result.append(_yaml_coerce(_yaml_unquote(item_str)))
                i += 1
            else:
                val, i = _parse_block(lines, i + 1, indent + 1)
                result.append(val)

        elif ':' in stripped:
            if result is None:
                result = {}
            key, rest = _split_kv(stripped)
            key = _yaml_unquote(key)
            rest = (rest or '').strip()
            if rest and not rest.startswith('"') and not rest.startswith("'"):
                rest = rest.split('#')[0].strip()

            if not rest:
                val, i = _parse_block(lines, i + 1, indent + 1)
            elif rest in ('|', '>'):
                val, i = _collect_block_scalar(lines, i + 1, indent + 1, rest)
            else:
                val = _yaml_coerce(_yaml_unquote(rest))
                i += 1

            if isinstance(result, dict):
                result[key] = val
        else:
            i += 1

    return result, i

def yaml_load(text):
    try:
        obj, _ = _parse_block(text.splitlines(), 0, 0)
        return obj
    except Exception:
        return None

# ── HTTP helpers ───────────────────────────────────────────────────────────────

def http_get(url, timeout=TIMEOUT):
    req = Request(url, headers={'User-Agent': 'autoswagger-minimal/1.0'})
    try:
        with urlopen(req, timeout=timeout, context=_SSL) as resp:
            return resp.status, dict(resp.headers), resp.read()
    except HTTPError as e:
        body = b''
        try:
            body = e.read()
        except Exception:
            pass
        return e.code, dict(e.headers) if e.headers else {}, body

def http_method(method, url, headers=None, data=None, timeout=TIMEOUT):
    global TOTAL_REQUESTS
    h = {'User-Agent': 'autoswagger-minimal/1.0'}
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        body = data.encode() if isinstance(data, str) else data
    req = Request(url, data=body, headers=h, method=method.upper())
    with _lock:
        TOTAL_REQUESTS += 1
    try:
        with urlopen(req, timeout=timeout, context=_SSL) as resp:
            return resp.status, dict(resp.headers), resp.read()
    except HTTPError as e:
        body_e = b''
        try:
            body_e = e.read()
        except Exception:
            pass
        return e.code, dict(e.headers) if e.headers else {}, body_e

# ── Spec fetching ──────────────────────────────────────────────────────────────

def _parse_spec(text, ctype=''):
    text = text.strip()
    if 'json' in ctype or text.startswith('{') or text.startswith('['):
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    spec = yaml_load(text)
    if isinstance(spec, dict):
        return spec
    try:
        return json.loads(text)
    except Exception:
        return None

def fetch_spec(url, verbose=False):
    if verbose:
        print(f"  [>] {url}")
    try:
        status, headers, body = http_get(url)
        if status != 200:
            return None
        text = body.decode('utf-8', errors='ignore')
        low = text.lower()
        if 'swagger' not in low and 'openapi' not in low:
            return None
        spec = _parse_spec(text, headers.get('Content-Type', ''))
        if spec and isinstance(spec, dict) and 'paths' in spec:
            if verbose:
                print(f"  [+] Spec found: {url}")
            return spec
    except (URLError, OSError) as e:
        if verbose:
            print(f"  [!] {url} — {e}")
    return None

def _extract_spec_url_from_html(html):
    for pat in [
        r'url:\s*["\']([^"\']+\.(?:json|yaml|yml))["\']',
        r'url:\s*["\']([^"\']+)["\']',
        r'SwaggerUIBundle\s*\(\s*{[^}]*url:\s*"([^"]+)"',
    ]:
        m = re.search(pat, html, re.DOTALL)
        if m:
            return m.group(1)
    # swashbuckle
    m = re.search(r'window\.swashbuckleConfig\s*=\s*{([\s\S]*?)};', html)
    if m:
        dp = re.findall(r'discoveryPaths\s*:\s*\[\s*["\']([^"\']+)["\']', m.group(1))
        if dp:
            return dp[0]
    return None

def _extract_spec_url_from_js(js):
    for pat in [
        r'url:\s*["\']([^"\']+\.(?:json|yaml|yml))["\']',
        r'url:\s*["\']([^"\']+)["\']',
        r'defaultDefinitionUrl\s*=\s*["\']([^"\']+)["\']',
    ]:
        m = re.search(pat, js)
        if m:
            return m.group(1)
    return None

def find_spec(base_url, verbose=False):
    # Phase 1: direct spec paths
    if verbose:
        print("[*] Phase 1: direct spec paths")
    for path in DIRECT_SPEC_PATHS:
        spec = fetch_spec(urljoin(base_url, path), verbose)
        if spec:
            return spec, urljoin(base_url, path)

    # Phase 2 & 3: Swagger UI HTML + JS scraping
    if verbose:
        print("[*] Phase 2: Swagger UI / JS scraping")
    for path in SWAGGER_UI_PATHS:
        ui_url = urljoin(base_url, path)
        try:
            status, _, body = http_get(ui_url)
            if status != 200:
                continue
            html = body.decode('utf-8', errors='ignore')
            if 'swagger' not in html.lower() and 'openapi' not in html.lower():
                continue
            if verbose:
                print(f"  [+] Swagger UI at {ui_url}")

            spec_url = _extract_spec_url_from_html(html)
            if spec_url:
                full = urljoin(ui_url, spec_url)
                spec = fetch_spec(full, verbose)
                if spec:
                    return spec, full

            js_files = re.findall(r'<script[^>]+src=["\']([^"\']+\.js)["\']', html, re.IGNORECASE)
            base_netloc = urlparse(base_url).netloc
            for jsf in js_files:
                js_url = urljoin(ui_url, jsf)
                if urlparse(js_url).netloc not in ('', base_netloc):
                    continue
                try:
                    js_status, _, js_body = http_get(js_url)
                    if js_status != 200:
                        continue
                    spec_url_js = _extract_spec_url_from_js(js_body.decode('utf-8', errors='ignore'))
                    if spec_url_js:
                        full_js = urljoin(js_url, spec_url_js)
                        spec = fetch_spec(full_js, verbose)
                        if spec:
                            return spec, full_js
                except (URLError, OSError):
                    continue
        except (URLError, OSError):
            continue

    return None, None

# ── Param / body helpers ───────────────────────────────────────────────────────

def _param_value(param):
    schema = param.get('schema', param)
    ptype = schema.get('type', 'string')
    enum = schema.get('enum')
    if enum:
        return enum[0]
    return TEST_VALUES.get(ptype, TEST_VALUES['default'])[0]

def _schema_to_value(schema):
    if not schema:
        return {}
    stype = schema.get('type', 'object')
    if stype == 'object':
        return {k: _schema_to_value(v) for k, v in schema.get('properties', {}).items()}
    if stype == 'array':
        return [_schema_to_value(schema.get('items', {}))]
    enum = schema.get('enum')
    if enum:
        return enum[0]
    return TEST_VALUES.get(stype, TEST_VALUES['default'])[0]

def _build_json_body(details):
    rb = details.get('requestBody', {})
    for ct, ct_data in rb.get('content', {}).items():
        if 'json' in ct:
            return json.dumps(_schema_to_value(ct_data.get('schema', {})))
    # Swagger2
    for p in details.get('parameters', []):
        if p.get('in') == 'body' and 'schema' in p:
            return json.dumps(_schema_to_value(p['schema']))
    return None

# ── Response helpers ───────────────────────────────────────────────────────────

def _format_size(n):
    if n >= 1024 * 1024:
        return f"{n/(1024*1024):.2f} MB"
    if n >= 1024:
        return f"{n/1024:.2f} KB"
    return f"{n} B"

def _extract_title(body_bytes):
    try:
        text = body_bytes.decode('utf-8', errors='ignore')
        m = re.search(r'<title[^>]*>([^<]+)</title>', text, re.IGNORECASE)
        if m:
            return m.group(1).strip()[:80]
    except Exception:
        pass
    return ''

def _colour_status(code):
    if 200 <= code < 300:
        return f"\033[32m{code}\033[0m"
    if 300 <= code < 400:
        return f"\033[36m{code}\033[0m"
    if 400 <= code < 500:
        return f"\033[33m{code}\033[0m"
    return f"\033[31m{code}\033[0m"

# ── Endpoint testing ───────────────────────────────────────────────────────────

def test_endpoint(base_url, base_path, path_tpl, method, details, rate, verbose):
    bp = (base_path or '').rstrip('/')
    full_path = bp + path_tpl
    parameters = details.get('parameters', [])

    for param in parameters:
        if param.get('in') == 'path':
            val = str(_param_value(param))
            name = param['name']
            full_path = re.sub(rf'\{{{name}\}}|:{name}', val, full_path)

    qp = {p['name']: _param_value(p) for p in parameters if p.get('in') == 'query'}
    qs = ('?' + urlencode(qp)) if qp else ''

    parsed = urlparse(base_url)
    full_url = f"{parsed.scheme}://{parsed.netloc}{full_path}{qs}"

    h = {}
    body_data = None
    if method.upper() in ('POST', 'PUT', 'PATCH'):
        body_data = _build_json_body(details)
        if body_data:
            h['Content-Type'] = 'application/json'

    if rate > 0:
        time.sleep(1.0 / rate)

    try:
        status, _, resp_body = http_method(method, full_url, headers=h, data=body_data)
    except (URLError, OSError) as e:
        if verbose:
            print(f"  [!] {method.upper()} {full_url} — {e}")
        return None

    return {
        'method': method.upper(),
        'url':    full_url,
        'status': status,
        'size':   len(resp_body),
        'title':  _extract_title(resp_body),
    }

def test_all_endpoints(base_url, base_path, spec, rate=30, include_risk=False,
                       verbose=False, workers=20):
    paths = spec.get('paths', {})
    if not paths:
        print("[!] No paths in spec.")
        return []

    tasks = []
    seen = set()
    for path_tpl, methods in paths.items():
        if not isinstance(methods, dict):
            continue
        for method, details in methods.items():
            if method.lower() not in ('get', 'post', 'put', 'patch', 'delete', 'head'):
                continue
            if method.upper() != 'GET' and not include_risk:
                continue
            key = (method.upper(), path_tpl)
            if key in seen:
                continue
            seen.add(key)
            tasks.append((path_tpl, method, details or {}))

    results = []
    total = len(tasks)
    done_count = [0]

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {
            ex.submit(test_endpoint, base_url, base_path, pt, m, d, rate, verbose): (m, pt)
            for pt, m, d in tasks
        }
        for fut in as_completed(futs):
            done_count[0] += 1
            sys.stderr.write(f"\r  [{done_count[0]}/{total}] testing endpoints...   ")
            sys.stderr.flush()
            r = fut.result()
            if r:
                results.append(r)

    sys.stderr.write('\n')
    return results

# ── Output ─────────────────────────────────────────────────────────────────────

def print_results(results, json_out=False):
    if json_out:
        print(json.dumps([
            {**r, 'size_human': _format_size(r['size'])}
            for r in results
        ], indent=2))
        return

    if not results:
        print("\n[!] No responses collected.")
        return

    results_sorted = sorted(results, key=lambda x: x['status'])

    # Dynamic column widths
    wm = max(6,  max(len(r['method']) for r in results))
    ws = 6
    wz = max(8,  max(len(_format_size(r['size'])) for r in results))
    wt = max(10, min(50, max(len(r['title']) for r in results) if any(r['title'] for r in results) else 10))
    wu = max(10, max(len(r['url']) for r in results))

    sep = f"+{'-'*(wm+2)}+{'-'*(ws+2)}+{'-'*(wz+2)}+{'-'*(wt+2)}+{'-'*(wu+2)}+"
    hdr = f"| {'METHOD':<{wm}} | {'STATUS':<{ws}} | {'SIZE':<{wz}} | {'TITLE':<{wt}} | {'URL':<{wu}} |"

    print(f"\n\033[1mResults — {len(results)} endpoint(s)\033[0m")
    print(sep)
    print(hdr)
    print(sep)
    for r in results_sorted:
        sc_raw = str(r['status'])
        sc_col = _colour_status(r['status'])
        title  = r['title'][:wt-1] + '…' if len(r['title']) > wt else r['title']
        # pad status manually (ANSI codes inflate len())
        sc_pad = sc_col + ' ' * (ws - len(sc_raw))
        print(f"| {r['method']:<{wm}} | {sc_pad} | {_format_size(r['size']):<{wz}} | {title:<{wt}} | {r['url']:<{wu}} |")
    print(sep)
    print(f"\n  Total requests fired: {TOTAL_REQUESTS}")

# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="autoswagger_minimal — stdlib-only Swagger endpoint tester",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python autoswagger_minimal.py https://api.example.com\n"
            "  python autoswagger_minimal.py https://api.example.com/swagger.json\n"
            "  python autoswagger_minimal.py https://api.example.com -risk -v\n"
            "  cat urls.txt | python autoswagger_minimal.py\n"
        )
    )
    parser.add_argument('urls', nargs='*', help='Target base URL(s) or direct spec URL(s)')
    parser.add_argument('-v', '--verbose', action='store_true', help='Show spec discovery details')
    parser.add_argument('-risk', action='store_true', help='Also test POST/PUT/PATCH/DELETE endpoints')
    parser.add_argument('-rate', type=int, default=30, help='Requests/sec per thread (default 30, 0=unlimited)')
    parser.add_argument('-w', '--workers', type=int, default=20, help='Thread pool size (default 20)')
    parser.add_argument('-json', dest='json_out', action='store_true', help='Output as JSON')
    args = parser.parse_args()

    if not args.urls and not sys.stdin.isatty():
        urls = [l.strip() for l in sys.stdin if l.strip()]
    else:
        urls = args.urls

    if not urls:
        parser.print_help()
        sys.exit(1)

    processed = []
    for u in urls:
        if not urlparse(u).scheme:
            u = 'https://' + u
        processed.append(u)

    all_results = []

    for base_url in processed:
        print(f"\n\033[1m[*] Target: {base_url}\033[0m")

        low = base_url.lower()
        if any(low.endswith(ext) for ext in ('.json', '.yaml', '.yml')):
            spec = fetch_spec(base_url, args.verbose)
            spec_url = base_url
        else:
            spec, spec_url = find_spec(base_url, args.verbose)

        if not spec:
            print(f"[!] No Swagger/OpenAPI spec found for {base_url}")
            continue

        print(f"[+] Spec  : {spec_url}")

        base_path = '/'
        if 'servers' in spec and isinstance(spec['servers'], list) and spec['servers']:
            srv = spec['servers'][0].get('url', '/')
            base_path = urlparse(srv).path or '/'
        elif 'basePath' in spec:
            base_path = spec.get('basePath', '/')

        print(f"[+] Paths : {len(spec.get('paths', {}))}")
        print(f"[+] Base  : {base_path}")

        results = test_all_endpoints(
            base_url, base_path, spec,
            rate=args.rate,
            include_risk=args.risk,
            verbose=args.verbose,
            workers=args.workers,
        )
        all_results.extend(results)

    print_results(all_results, json_out=args.json_out)


if __name__ == '__main__':
    main()